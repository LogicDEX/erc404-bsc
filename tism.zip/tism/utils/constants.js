const CONTRACT_NAMES = {
  MY_ERC404: 'MyERC404',
};

module.exports = { CONTRACT_NAMES };
